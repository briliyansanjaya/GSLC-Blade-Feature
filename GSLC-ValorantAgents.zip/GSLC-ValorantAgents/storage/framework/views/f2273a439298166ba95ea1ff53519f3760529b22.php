<nav class="navbar" style="height: 60px; background-color: 1B2733">
    <div class="container-fluid">
        <a class="navbar-brand" href="/">
            <img src="https://earlygame-prod.cdn.earlygame.com/images/Valorant-Logo_2021-09-17-094641_jsqj.png" alt="Valorant" width="135" height="40">
        </a>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\GSLC-ValorantAgents\resources\views/components/navbar.blade.php ENDPATH**/ ?>